import React from 'react'

const DeleteAllItemsComp = () => {
  return (
    <div>
      
    </div>
  )
}

export default DeleteAllItemsComp
