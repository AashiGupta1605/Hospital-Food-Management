import React from 'react'

const DeleteAllRootCategoriesComp = () => {
  return (
    <div>
      
    </div>
  )
}

export default DeleteAllRootCategoriesComp
