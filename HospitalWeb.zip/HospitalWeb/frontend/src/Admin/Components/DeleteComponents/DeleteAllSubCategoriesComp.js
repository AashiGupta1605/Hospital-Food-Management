import React from 'react'

const DeleteAllSubCategoriesComp = () => {
  return (
    <div>
      
    </div>
  )
}

export default DeleteAllSubCategoriesComp
