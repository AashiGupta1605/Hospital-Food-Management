import React from 'react'

const UpdateItemComp = () => {
  return (
    <div>
      
    </div>
  )
}

export default UpdateItemComp
