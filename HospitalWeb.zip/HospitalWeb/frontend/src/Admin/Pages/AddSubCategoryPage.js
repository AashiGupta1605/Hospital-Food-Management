import React from 'react'
import AddSubCategoryComp from '../Components/AddComponents/AddSubCategoryComp'

const AddSubCategoryPage = () => {
return (
    <>
    <AddSubCategoryComp/>
    </>
)
}

export default AddSubCategoryPage
