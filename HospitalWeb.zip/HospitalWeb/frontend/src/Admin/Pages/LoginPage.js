import React from 'react';
import LoginComp from '../Components/LoginComp';

const LoginPage = () => {
return (
    <>
    <LoginComp/>
    </>
)
}

export default LoginPage
