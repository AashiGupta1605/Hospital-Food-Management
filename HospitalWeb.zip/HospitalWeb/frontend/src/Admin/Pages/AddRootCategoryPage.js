import React from 'react'
import AddRootCategoryComp from '../Components/AddComponents/AddRootCategoryComp'

const AddRootCategoryPage = () => {
return (
    <>
    <AddRootCategoryComp/>
    </>
)
}

export default AddRootCategoryPage
