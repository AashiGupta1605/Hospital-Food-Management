import React from 'react'
import AddItemComp from '../Components/AddComponents/AddItemComp'

const AddItemPage = () => {
return (
    <>
    <br/>
    <AddItemComp/>
    </>
)
}

export default AddItemPage
